MdlxConv 1.01
Released 3-3-07
Contact: PM Guesst at www.wc3campaigns.net

This program converts between Warcraft III MDX and MDL
files. Unlike Yobguls' converter, it will not crash
constantly. Also, it will give somewhat niceerror 
messages instead of just yelling at you. However,
because it does not used the game DLLs, it can not be 
entirely trusted too. If you find a bug, please do tell.

Usage:
 - Click "Convert" and choose one or more files to convert.
 - Click "Repeat" to do the last batch over again. This 
   is useful if you had an error in your MDL and just went
   back to fix it.
 - You can also click and drag files onto the program
   from Explorer or open MDL/X files with it. This makes
   converting a file as easy as going into the right click
   menu in Explorer.


Change log
1.03
 Bug fix on ParticleEmitter2s
 Bug fix for single-dimension Bezier animations.

1.02
 Handles ParticleEmitters
 File dialog remembers the type

1.01
 Public release